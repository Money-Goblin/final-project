import tkinter as tk
from tkinter import PhotoImage
"""Functions that allow the second window to change states depending on the button pressed"""
"""Background colors, images shown, and label text are changed in these functions"""
def emotionChangeHappy():
    emotionLabel.config(text="Emotion: Happy")
    win2.config(background="yellow")
    happyLabel.place(anchor="s",relx=.5,rely=.9)
    angryLabel.place_forget()
    sadLabel.place_forget()
def emotionChangeSad():
    emotionLabel.config(text="Emotion: Sad")
    win2.config(background="blue")
    sadLabel.place(anchor="s",relx=.5,rely=.95)
    angryLabel.place_forget()
    happyLabel.place_forget()
def emotionChangeAngry():
    emotionLabel.config(text="Emotion: Angry")
    win2.config(background="red")
    angryLabel.place(anchor="s", relx=.5,rely=.95)
    happyLabel.place_forget()
    sadLabel.place_forget()
"""Initialization and configuration of the main windows"""    
root = tk.Tk()    
win2 = tk.Toplevel()
root.resizable(False,False)
root.title("Emotion Selector")
root.geometry("350x200")
win2.resizable(False,False)
win2.title("Emotional Window")
"""Initialization of the buttons, labels, and images"""
sadButton = tk.Button(root, text="Demean", command=emotionChangeSad)
angryButton = tk.Button(root, text="Insult",command=emotionChangeAngry)
happyButton = tk.Button(root, text="Compliment", command=emotionChangeHappy)
quitButton = tk.Button(root, text="Quit",command=quit)
promptLabel = tk.Label(root, text="Choose an action. The second window will react.")
emotionLabel = tk.Label(win2, text="Emotion: Neutral")
happyImage = PhotoImage(file="happy.png")
sadImage= PhotoImage(file="sad.png")
angryImage = PhotoImage(file="angry.png")
angryLabel = tk.Label(win2,image=angryImage)
sadLabel= tk.Label(win2,image=sadImage)
happyLabel=tk.Label(win2,image=happyImage)
"""Placement of the buttons and labels"""
promptLabel.place(anchor="s",relx=.5,rely=.2)
emotionLabel.place(anchor="center", relx=.5,rely=.1)
quitButton.place(anchor="s", relx=.8,rely=.8)
sadButton.place(anchor="s",relx=.2,rely=.8)
angryButton.place(anchor="s",relx=.4,rely=.8)
happyButton.place(anchor="s",relx=.6,rely=.8)
"""Begins the main loop of the GUI"""
root.mainloop()